package com.example.administrator.callphone.utils;

/**
 * Created by Administrator on 2018/5/29.
 */

public interface RequestPermissionType {
    /**
     * 请求打电话的权限码
     */
    int REQUEST_CODE_ASK_CALL_PHONE = 100;
}
