package com.example.administrator.callphone;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.administrator.callphone.service.CallPhoneBroadcastReceiver;
import com.example.administrator.callphone.utils.DialogUtil;
import com.example.administrator.callphone.utils.RequestPermissionType;

public class MainActivity extends AppCompatActivity {

    /**
     * 上下文对象
     * context
     */
    private Context mContext;

    /**
     * 用户的手机号码
     */
    private String phoneNum;

    /**
     * 用户输入账号
     */
    private EditText editText;

    private Button button;

    private CallPhoneBroadcastReceiver callPhoneBroadcastReceiver;
    private final static String CALL_PHONE_ACTION = "android.intent.action.NEW_OUTGOING_CALL";
    private IntentFilter intentFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.input_edit);
        button = findViewById(R.id.openService);
        this.mContext = this;
        initClick();
    }

    private void initClick() {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerPhone();
            }
        });
    }

    private void registerPhone() {
        Toast.makeText(this,"注册服务中...",Toast.LENGTH_SHORT).show();
        callPhoneBroadcastReceiver = new CallPhoneBroadcastReceiver();
        intentFilter = new IntentFilter(CALL_PHONE_ACTION);
        registerReceiver(callPhoneBroadcastReceiver,intentFilter);
    }

    /**
     * 点击打电话的按钮响应事件
     *
     * @param view view
     */
    public void callButtonClickAction(View view)
    {

        //先new出一个监听器，设置好监听
        DialogInterface.OnClickListener dialogOnclicListener = new DialogInterface.OnClickListener()
        {

            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                switch (which)
                {
                    case Dialog.BUTTON_POSITIVE:
                        Toast.makeText(MainActivity.this, "Yes" + which, Toast.LENGTH_SHORT).show();
                        requestPermission();
                        break;
                    case Dialog.BUTTON_NEGATIVE:
                        Toast.makeText(MainActivity.this, "No" + which, Toast.LENGTH_SHORT).show();
                        break;
                    case Dialog.BUTTON_NEUTRAL:
                        Toast.makeText(MainActivity.this, "Cancel" + which, Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };

        //弹窗让用户选择，是否允许申请权限
        DialogUtil.showConfirm(mContext, "申请权限", "是否允许获取打电话权限？", dialogOnclicListener, dialogOnclicListener);
    }

    /**
     * 申请权限
     */
    private void requestPermission()
    {
        //判断Android版本是否大于23
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            int checkCallPhonePermission = ContextCompat.checkSelfPermission(mContext, Manifest.permission.CALL_PHONE);

            if (checkCallPhonePermission != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},
                        RequestPermissionType.REQUEST_CODE_ASK_CALL_PHONE);
                return;
            }
            else
            {
                callPhone();
            }
        }
        else
        {
            callPhone();
        }
    }

    /**
     * 注册权限申请回调
     * @param requestCode 申请码
     * @param permissions 申请的权限
     * @param grantResults 结果
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        switch (requestCode)
        {
            case  RequestPermissionType.REQUEST_CODE_ASK_CALL_PHONE:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    callPhone();
                }
                else
                {
                    // Permission Denied
                    Toast.makeText(MainActivity.this, "CALL_PHONE Denied", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    /**
     * 拨号方法
     */
    private void callPhone()
    {
        phoneNum = editText.getText().toString();
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:"+phoneNum));
        startActivity(intent);
    }
}
