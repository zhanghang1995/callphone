package com.example.administrator.callphone.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.SystemClock;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import java.io.IOException;
import java.lang.reflect.Method;

/**
 * 拦截电话服务
 * Created by Administrator on 2018/5/30.
 */

public class CallPhoneBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent)
    {
        AudioManager mAudioManager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);

        String inComingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);//去电
        String outGogingNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER); //来电

        String phoneState = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

        if(Intent.ACTION_NEW_OUTGOING_CALL.equals(intent.getAction()))
        {
            if (outGogingNumber == null) {
                outGogingNumber = getResultData();
            }
            if (shouldCancel(outGogingNumber)) //判断号码是不是需要拦截
            {
                mAudioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                setResultData(null);
                mAudioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            } else {
                setResultData(reformatNumber(outGogingNumber));
            }
            Log.i("TAG", "去电号码：phoneState="+phoneState+",phoneNumber="+outGogingNumber);
        }
        //判断是否为来电信息
        else if(!TextUtils.isEmpty(inComingNumber) && TelephonyManager.EXTRA_STATE_RINGING.equals(phoneState))
        {
            Toast.makeText(context,"来电号码：inComingNumber="+phoneState+",phoneNumber="+inComingNumber,Toast.LENGTH_SHORT).show();
            //判断当前当前版本是否大于Android8.0
            if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
                TelecomManager telecomManager =
                        (TelecomManager) context.getSystemService(context.TELECOM_SERVICE);
                Method method = null;
                try {
                    method = Class.forName("android.telecom.TelecomManager").getMethod("acceptRingingCall");
                    method.invoke(telecomManager);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else if(Build.VERSION.SDK_INT<=Build.VERSION_CODES.KITKAT){
                try {
                    Runtime.getRuntime().exec("input keyevent " + Integer.toString(KeyEvent.KEYCODE_HEADSETHOOK));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }else{
                 /* 模拟耳机插入动作,用于接听电话 */
                Toast.makeText(context,"接听电话",Toast.LENGTH_SHORT).show();
                AudioManager audioManager = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
                long eventTime = SystemClock.uptimeMillis() - 1;
                KeyEvent eventDown = new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_HEADSETHOOK);
                KeyEvent eventUp = new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_HEADSETHOOK);
                audioManager.dispatchMediaKeyEvent(eventDown);
                audioManager.dispatchMediaKeyEvent(eventUp);
            }
        }

    }

    //此处直接进行拨打
    private String reformatNumber(String phoneNumber) {

        return "17951".concat(phoneNumber);
    }
    //此处进行号码的黑名单拦截操作
    private boolean shouldCancel(String phoneNumber) {
        return "13002248003".equals(phoneNumber);
    }

}
