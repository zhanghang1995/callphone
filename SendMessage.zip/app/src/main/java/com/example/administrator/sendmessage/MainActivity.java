package com.example.administrator.sendmessage;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity{
    private EditText phone,message;
    private Button sendBtn,jumpBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        sendMesge();
        jumpPage();
    }

    private void jumpPage() {
        jumpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(MainActivity.this,MainActivityDirect.class);
                startActivity(intent);
            }
        });
    }


    private void initView() {
        phone = findViewById(R.id.phoneNum);
        message = findViewById(R.id.messageInfo);
        sendBtn = findViewById(R.id.sendBtn);
        jumpBtn = findViewById(R.id.jumpAnother);
    }

    /**
     * 发送短信
      */
    private void sendMesge() {
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = phone.getText().toString();
                String messageContent = message.getText().toString();
                Uri smstoUri = Uri.parse("smsto:");//解析地址
                Intent intent = new Intent(Intent.ACTION_VIEW,smstoUri);
                //没有电话号码的话为默认，即显示的时候为空
                intent.putExtra("address",phoneNumber);
                //设置发送的内容
                intent.putExtra("sms_body",messageContent);
                intent.setType("vnd.android-dir/mms-sms");
                startActivity(intent);
            }
        });
    }


}
