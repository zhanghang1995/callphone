package com.example.administrator.sendmessage;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.administrator.sendmessage.service.SmsReceiver;

import java.util.List;

public class MainActivityDirect extends AppCompatActivity {
    private EditText phone,message;
    private Context mContext;
    private Button sendBtn;
    private final String TAG = getClass().getSimpleName();
    private SMSBroadcastReceiver1 smsBroadcastReceiver1;
    private SMSBroadcastReceiver2 smsBroadcastReceiver2;
    private IntentFilter intentFilter1;
    private IntentFilter intentFilter2;
    private IntentFilter intentFilter3;
    private SmsReceiver smsReceiver;
    private final static String SENT_SMS_ACTION = "SENT_SMS_ACTION";
    private final static String DELIVERED_SMS_ACTION = "DELIVERED_SMS_ACTION";
    private final static String SMS_MESSAGE = "android.provider.Telephony.SMS_RECEIVED";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_direct);
        this.mContext = this;
        initView();
//        initBroadcast();
        sendMessage();
    }

    private void sendMessage() {
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               requestPermission();
//               recevieMessage();
          }
        });
    }

    private void recevieMessage() {
        //判断Android版本是否大于23
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            int checkCallPhonePermission = ContextCompat.checkSelfPermission(mContext, Manifest.permission.RECEIVE_SMS);

            if (checkCallPhonePermission != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS},
                        103);
                return;
            }
            else
            {
                registerMessage();
            }
        }
        else
        {
            registerMessage();
        }
    }




    //for version 4.1 or larger

    private void registerMessage() {
        Toast.makeText(this,"注册服务中...",Toast.LENGTH_SHORT).show();
        smsReceiver = new SmsReceiver();
        intentFilter3 = new IntentFilter(SMS_MESSAGE);
        registerReceiver(smsReceiver,intentFilter3);
    }

    private void requestPermission(){
        //判断Android版本是否大于23
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            int checkCallPhonePermission = ContextCompat.checkSelfPermission(mContext, Manifest.permission.SEND_SMS);

            if (checkCallPhonePermission != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},
                        102);
                return;
            }
            else
            {
                sendMessage1(phone.getText().toString(),message.getText().toString());
            }
        }
        else
        {
            sendMessage1(phone.getText().toString(),message.getText().toString());
        }
    }
    /**
     * 权限请求的回掉
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case 102:
                if (grantResults[0]== PackageManager.PERMISSION_GRANTED){
                sendMessage1(phone.getText().toString(),message.getText().toString());
                }else{
                    Toast.makeText(this,"你没有启动权限",Toast.LENGTH_SHORT).show();
                }
                break;
            case 103:
                if (grantResults[0]== PackageManager.PERMISSION_GRANTED){
                    registerMessage();
                }else{
                    Toast.makeText(this,"你没有启动权限",Toast.LENGTH_SHORT).show();
                }
                break;
        }

    }

    /**
     * 发送短信
     *
     * @param tel     电话号码
     * @param content 短息内容
     */
    private void sendMessage1(String tel, String content) {
        Intent sendIntent = new Intent(SENT_SMS_ACTION);
        PendingIntent sendPI = PendingIntent.getBroadcast(this, 0, sendIntent, 0);

        SmsManager smsManager = SmsManager.getDefault();
        List<String> divideContents = smsManager.divideMessage(content);
        for (String text : divideContents) {
            smsManager.sendTextMessage(tel, null, text, sendPI, null);
        }
    }

    /**
     * 发送短信
     *
     * @param tel     电话号码
     * @param content 短息内容
     */
    private void sendMessage2(String tel, String content) {
        Intent deliverIntent = new Intent(DELIVERED_SMS_ACTION);
        PendingIntent deliverPI = PendingIntent.getBroadcast(this, 0, deliverIntent, 0);

        SmsManager smsManager = SmsManager.getDefault();
        List<String> divideContents = smsManager.divideMessage(content);
        for (String text : divideContents) {
            smsManager.sendTextMessage(tel, null, text, null, deliverPI);
        }
    }

    //注册广播
    private void initBroadcast() {
        smsBroadcastReceiver1 = new SMSBroadcastReceiver1();
        intentFilter1 = new IntentFilter(SENT_SMS_ACTION);
        registerReceiver(smsBroadcastReceiver1,intentFilter1);

        smsBroadcastReceiver2 = new SMSBroadcastReceiver2();
        intentFilter2 = new IntentFilter(DELIVERED_SMS_ACTION);
        registerReceiver(smsBroadcastReceiver2,intentFilter2);

    }

    private void initView() {
        phone = findViewById(R.id.phoneNum);
        message = findViewById(R.id.messageInfo);
        sendBtn = findViewById(R.id.sendBtn);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        unregisterReceiver(smsBroadcastReceiver1);
//        unregisterReceiver(smsBroadcastReceiver2);
        unregisterReceiver(smsReceiver);
    }

    private class SMSBroadcastReceiver1 extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (getResultCode()) {
                case Activity.RESULT_OK:
                    Toast.makeText(context, "短信发送成功SMS1", Toast.LENGTH_SHORT).show();
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    Log.e(TAG, "SmsManager.RESULT_ERROR_GENERIC_FAILURE");
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    Log.e(TAG, "SmsManager.RESULT_ERROR_RADIO_OFF");
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    Log.e(TAG, "SmsManager.RESULT_ERROR_NULL_PDU");
                    break;
            }
        }
    }

    private class SMSBroadcastReceiver2 extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, "短信发送成功SMS2", Toast.LENGTH_SHORT).show();
        }
    }

}
